package org.claimsystem.oldfile;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class ClaimDBMS {
    public static void main(String[] args) {
        ClaimPostgreSQL claimPostgreSQL = new ClaimPostgreSQL();
        Connection conn = claimPostgreSQL.connectToDB("claim_system", "postgres", "123456789");
        claimPostgreSQL.createTable(conn,"claim_table"); // create a claim table
        List<ClaimB> claimList = createList();
        for (ClaimB claim: claimList) {
            claimPostgreSQL.insertRow(conn, "claim_table", claim);
        }
//        claimPostgreSQL.readData(conn, "claim_table");
//        claimPostgreSQL.updateData(conn, "claim_table", "f2211334455", "receiver_bank", "update_vcb");
//        claimPostgreSQL.updateData(conn,"claim_table", "f2211334455", "claim_date", "2023-03-15");
//        claimPostgreSQL.readData(conn, "claim_table");
//        claimPostgreSQL.searchData(conn, "claim_table", Map.of("status", "DONE"));
//        claimPostgreSQL.searchData(conn, "claim_table", Map.of("insured_person", "c1234754"));
        System.out.println("Delete data with claim_id = f2211334455");
//        claimPostgreSQL.deleteRow(conn, "claim_table", "f2211334455");
        claimPostgreSQL.readData(conn, "claim_table");
        claimPostgreSQL.searchData(conn, "claim_table", Map.of("status", "DONE"));
    }

    public static List<ClaimB> createList() {
        ClaimB claimB1 = new ClaimB.ClaimBuilder("f1122334455", "c1234567").cardNumber("1234567890")
                .claimAmount(1000)
                .claimDate(LocalDate.of(2024, 1, 1))
                .examDate(LocalDate.of(2024, 2, 1))
                .claimStatus(ClaimB.ClaimBuilder.ClaimStatus.NEW)
                .documents(List.of("document1", "document2"))
                .receiverBank("Vietcombank")
                .build();

        ClaimB claimB2 = new ClaimB.ClaimBuilder("f2211334455", "c1234567").cardNumber("2134567890")
                .claimAmount(300)
                .claimDate(LocalDate.of(2023, 3, 1))
                .examDate(LocalDate.of(2023, 5, 1))
                .claimStatus(ClaimB.ClaimBuilder.ClaimStatus.PROCESSING)
                .documents(List.of("document3", "document4"))
                .receiverBank("Vietinbank")
                .build();

        ClaimB claimB3 = new ClaimB.ClaimBuilder("f3322114455", "c1234754")
                .claimAmount(1500)
                .cardNumber("1234567900")
                .claimDate(LocalDate.of(2022, 1, 1))
                .examDate(LocalDate.of(2022, 2, 1))
                .claimStatus(ClaimB.ClaimBuilder.ClaimStatus.DONE)
                .documents(List.of("document5", "document6"))
                .receiverBank("Agribank")
                .build();

        ClaimB claimB4 = new ClaimB.ClaimBuilder("f4433221455", "c1234754")
                .claimAmount(6000)
                .cardNumber("1235467900")
                .claimDate(LocalDate.of(2019, 1, 1))
                .examDate(LocalDate.of(2021, 2, 1))
                .claimStatus(ClaimB.ClaimBuilder.ClaimStatus.DONE)
                .documents(List.of("document7", "document8"))
                .receiverBank("BIDV")
                .build();

        ClaimB claimB5 = new ClaimB.ClaimBuilder("f5544332211", "c1236345")
                .claimAmount(7200)
                .cardNumber("1234587007")
                .claimDate(LocalDate.of(2017, 1, 1))
                .examDate(LocalDate.of(2020, 2, 1))
                .claimStatus(ClaimB.ClaimBuilder.ClaimStatus.DONE)
                .documents(List.of("document9", "document10"))
                .receiverBank("Techcombank")
                .build();
        List<ClaimB> claimList1 = new ArrayList<>();
        claimList1.add(claimB1);
        claimList1.add(claimB2);
        claimList1.add(claimB3);
        claimList1.add(claimB4);
        claimList1.add(claimB5);
        return claimList1;
    }
}