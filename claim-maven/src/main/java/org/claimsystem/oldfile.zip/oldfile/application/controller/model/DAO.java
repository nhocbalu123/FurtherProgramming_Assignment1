package org.claimsystem.oldfile.application.controller.model;

import java.text.ParseException;
import java.util.Optional;
import java.util.stream.Stream;

public interface DAO<T> {
    Optional<T> getOne(String id); // select by id

    Stream<T> getAll();

    void add(T t);

    void update(T t) throws ParseException;

    void delete(T t);
}
