create table account(
accountID varchar(10) primary key not null,
accountName varchar(50) not null,
password varchar(50) not null,
createAt date not null
);

create table policy_holder (
phID varchar(10) primary key not null,
phName varchar(50) not null,
accountID varchar(10) unique not null,
foreign key (accountID) references account(accountID)
);

create table dependent(
dID varchar(10) not null,
dName varchar(50) not null,
accountID varchar(10) unique not null,
phID varchar(10) not null,
primary key (dID, phID),
foreign key (phID) references policy_holder(phID),
foreign key (accountID) references account(accountID)
);

-- drop table if exists dependent;

create table policy_owner(
pwID varchar(10) primary key not null,
pwName varchar(50) not null,
accountID varchar(10) unique not null,
foreign key (accountID) references account(accountID)
);

create table provider(
pID varchar(10) primary key not null,
pName varchar(50) not null,
accountID varchar(10) unique not null,
managerID varchar(10),
foreign key (accountID) references account(accountID)
);

-- drop table if exists provider;

create table sys_admin(
adminID varchar(10) primary key not null,
adminName varchar(50) not null,
accountID varchar (10) unique not null,
foreign key (accountID) references account(accountID)
);


create table session(
sessionID varchar(10) primary key not null,
accountID varchar(10) not null,
startAt timestamp not null,
endAt timestamp not null,
foreign key (accountID) references account(accountID)
);

-- drop table if exists session;

create table log(
logID varchar(10) primary key not null,
accountID varchar(10) not null,
actionType varchar(10) not null,
alterTable varchar(20) not null,
alterColumn varchar(20) not null,
entityID varchar(10) not null,
oldValue jsonb not null,
newValue jsonb not null,
actionTime timestamp not null,
foreign key (accountID) references account(accountID)
);

-- drop table if exists log;


create table policy(
policyID varchar(10) primary key not null,
policyName varchar(30) not null,
policyType varchar(30) not null,
coverRate decimal(10,2) not null,
pwID varchar(10) not null,
foreign key (pwID) references policy_owner(pwID)
);


create table claim(
claimID varchar(20) primary key not null,
insuredPerson varchar(10) not null,
claimDate timestamp not null,
examDate timestamp not null,
requestAmount decimal(10,2) not null,
claimAmount decimal(10,2),
claimStatus varchar(10) not null,
bankAccNumber varchar(30) not null,
policyID varchar(10) not null,
provider varchar(10) not null,
foreign key (policyID) references policy(policyID),
foreign key (provider) references provider(pID),
foreign key (bankAccNumber) references bank(bankAccNumber)
);

-- drop table if exists claim;

create table bank(
bankAccNumber varchar(50) primary key not null,
bankAccName varchar(50) not null,
bankName varchar(50) not null,
bankCode varchar(10) not null
);

-- drop table if exists bank;


CREATE TABLE insurance_card (
cardNum VARCHAR(20) PRIMARY KEY NOT NULL,
phID VARCHAR(10) NOT NULL,
pwID VARCHAR(10) NOT NULL,
expiredDate DATE NOT NULL,
FOREIGN KEY (phID) REFERENCES policy_holder(phID),
FOREIGN KEY (pwID) REFERENCES policy_owner(pwID)
);

CREATE TABLE document (
docID VARCHAR(10) PRIMARY KEY NOT NULL,
docName VARCHAR(50) NOT NULL,
docContent varchar(100) not null,
image BYTEA,
claimID VARCHAR(20) NOT NULL,
FOREIGN KEY (claimID) REFERENCES claim(claimID)
);

-- drop table if exists document;


INSERT INTO account (accountID, accountName, password, createAt)
VALUES
('acc001', 'Account 1', 'password1', '2024-04-23'),
('acc002', 'Account 2', 'password2', '2024-04-23'),
('acc003', 'Account 3', 'password3', '2024-04-23'),
('acc004', 'Account 4', 'password4', '2024-04-23'),
('acc005', 'Account 5', 'password5', '2024-04-23');




INSERT INTO policy_holder (phID, phName, accountID)
VALUES
('c1234567', 'John Doe', 'acc001'),
('c1234568', 'Alice Smith', 'acc002'),
('c1234569', 'Bob Johnson', 'acc003'),
('c1234570', 'Charlie Brown', 'acc004'),
('c1234571', 'Diana Garcia', 'acc005');


-- Inserting data into the policy_owner table

INSERT INTO account (accountID, accountName, password, createAt)
VALUES
('acc700', 'ABC Insurance', 'password123', '2024-04-23'),
('acc701', 'XYZ Insurance', 'password456', '2024-04-23'),
('acc702', 'DEF Assurance', 'password789', '2024-04-23'),
('acc703', 'GHI Coverage', 'passwordabc', '2024-04-23'),
('acc704', 'JKL Underwriters', 'passwordxyz', '2024-04-23');

INSERT INTO policy_owner (pwID, pwName, accountID)
VALUES
('c7654321', 'ABC Insurance', 'acc700'),
('c7654322', 'XYZ Insurance', 'acc701'),
('c7654323', 'DEF Assurance', 'acc702'),
('c7654324', 'GHI Coverage', 'acc703'),
('c7654325', 'JKL Underwriters', 'acc704');

-- Inserting data into the account table for each dependent
INSERT INTO account (accountID, accountName, password, createAt)
VALUES
('acc201', 'Dependent Account 1', 'password_dep1', '2024-04-23'),  -- for dependent 1
('acc202', 'Dependent Account 2', 'password_dep2', '2024-04-23'),  -- for dependent 2
('acc203', 'Dependent Account 3', 'password_dep3', '2024-04-23'),  -- for dependent 3
('acc204', 'Dependent Account 4', 'password_dep4', '2024-04-23'),  -- for dependent 4
('acc205', 'Dependent Account 5', 'password_dep5', '2024-04-23');  -- for dependent 5

INSERT INTO dependent (dID, dName, accountID, phID)
VALUES
('c2134567', 'Bon Jovi', 'acc201', 'c1234567'),  -- John Doe
('c2134568', 'Depeche Mode', 'acc202', 'c1234567'),  -- John Doe
('c2134569', 'Taylor Swift', 'acc203', 'c1234568'),  -- Alice Smith
('c2134570', 'Slowdive', 'acc204', 'c1234569'),  -- Bob Johnson
('c2134571', 'Kanye West', 'acc205', 'c1234571');  -- Diana Garcia

-- Inserting data into the account table for the providers
INSERT INTO account (accountID, accountName, password, createAt)
VALUES
('acc011', 'Provider Account 1', 'password_prov1', '2024-04-23'),
('acc012', 'Provider Account 2', 'password_prov2', '2024-04-23'),
('acc013', 'Provider Account 3', 'password_prov3', '2024-04-23'),
('acc014', 'Provider Account 4', 'password_prov4', '2024-04-23'),
('acc015', 'Provider Account 5', 'password_prov5', '2024-04-23');

INSERT INTO provider (pID, pName, accountID, managerID)
VALUES
('p1234567', 'Provider 1', 'acc011', 'p1234570'),
('p1234568', 'Provider 2', 'acc012', 'p1234570'),
('p1234569', 'Provider 3', 'acc013', 'p1234570'),
('p1234570', 'Provider 4', 'acc014', 'p1234571'),
('p1234571', 'Provider 5', 'acc015', 'p1234571');

-- Inserting data into the account table for the sys_admins
INSERT INTO account (accountID, accountName, password, createAt)
VALUES
('acc016', 'SysAdmin Account 1', 'password_sa1', '2024-04-23'),
('acc017', 'SysAdmin Account 2', 'password_sa2', '2024-04-23'),
('acc018', 'SysAdmin Account 3', 'password_sa3', '2024-04-23'),
('acc019', 'SysAdmin Account 4', 'password_sa4', '2024-04-23'),
('acc020', 'SysAdmin Account 5', 'password_sa5', '2024-04-23');

INSERT INTO sys_admin (adminID, adminName, accountID)
VALUES
('sa001', 'SysAdmin 1', 'acc016'),
('sa002', 'SysAdmin 2', 'acc017'),
('sa003', 'SysAdmin 3', 'acc018'),
('sa004', 'SysAdmin 4', 'acc019'),
('sa005', 'SysAdmin 5', 'acc020');

-- Inserting data into the session table
INSERT INTO session (sessionID, accountID, startAt, endAt)
VALUES
('sess001', 'acc001', '2024-04-23 08:00:00', '2024-04-23 12:00:00'),
('sess002', 'acc002', '2024-04-23 10:00:00', '2024-04-23 14:00:00'),
('sess003', 'acc003', '2024-04-23 12:00:00', '2024-04-23 16:00:00'),
('sess004', 'acc004', '2024-04-23 14:00:00', '2024-04-23 18:00:00'),
('sess005', 'acc005', '2024-04-23 16:00:00', '2024-04-23 20:00:00'),
('sess006', 'acc700', '2024-04-23 08:00:00', '2024-04-23 12:00:00'),
('sess007', 'acc701', '2024-04-23 10:00:00', '2024-04-23 14:00:00'),
('sess008', 'acc702', '2024-04-23 12:00:00', '2024-04-23 16:00:00'),
('sess009', 'acc703', '2024-04-23 14:00:00', '2024-04-23 18:00:00'),
('sess010', 'acc704', '2024-04-23 16:00:00', '2024-04-23 20:00:00'),
('sess011', 'acc201', '2024-04-23 08:00:00', '2024-04-23 12:00:00'),
('sess012', 'acc202', '2024-04-23 10:00:00', '2024-04-23 14:00:00'),
('sess013', 'acc203', '2024-04-23 12:00:00', '2024-04-23 16:00:00'),
('sess014', 'acc204', '2024-04-23 14:00:00', '2024-04-23 18:00:00'),
('sess015', 'acc205', '2024-04-23 16:00:00', '2024-04-23 20:00:00'),
('sess016', 'acc011', '2024-04-23 08:00:00', '2024-04-23 12:00:00'),
('sess017', 'acc012', '2024-04-23 10:00:00', '2024-04-23 14:00:00'),
('sess018', 'acc013', '2024-04-23 12:00:00', '2024-04-23 16:00:00'),
('sess019', 'acc014', '2024-04-23 14:00:00', '2024-04-23 18:00:00'),
('sess020', 'acc015', '2024-04-23 16:00:00', '2024-04-23 20:00:00'),
('sess021', 'acc016', '2024-04-23 08:00:00', '2024-04-23 12:00:00'),
('sess022', 'acc017', '2024-04-23 10:00:00', '2024-04-23 14:00:00'),
('sess023', 'acc018', '2024-04-23 12:00:00', '2024-04-23 16:00:00'),
('sess024', 'acc019', '2024-04-23 14:00:00', '2024-04-23 18:00:00'),
('sess025', 'acc020', '2024-04-23 16:00:00', '2024-04-23 20:00:00');


INSERT INTO policy (policyID, policyName, policyType, coverRate, pwID)
VALUES
('pol001', 'Life Insurance', 'Life', 0.95, 'c7654321'),
('pol002', 'Health Insurance', 'Health', 0.90, 'c7654321'),
('pol003', 'Car Insurance', 'Auto', 0.85, 'c7654322'),
('pol004', 'Home Insurance', 'Property', 0.80, 'c7654323'),
('pol005', 'Travel Insurance', 'Travel', 0.75, 'c7654324');

INSERT INTO claim (claimID, insuredPerson, claimDate, examDate, requestAmount, claimAmount, claimStatus, bankAccNumber, policyID, provider)
VALUES
('f1122334455', 'c1234567', '2024-04-01 08:00:00', '2024-04-10 10:00:00', 5000.00, NULL, 'Approved', '1234567890', 'pol001', 'p1234567'),
('f2211334455', 'c1234567', '2024-04-05 09:00:00', '2024-04-15 11:00:00', 7000.00, NULL, 'Pending', '1234567890', 'pol002', 'p1234567'),
('f3311224455', 'c1234568', '2024-04-10 10:00:00', '2024-04-20 12:00:00', 6000.00, NULL, 'Approved', '2345678901', 'pol003', 'p1234567'),
('f4411324455', 'c2134568', '2024-04-15 11:00:00', '2024-04-25 13:00:00', 8000.00, NULL, 'Pending', '2345678901', 'pol004', 'p1234570'),
('f5544332211', 'c2134571', '2024-04-20 12:00:00', '2024-04-30 14:00:00', 9000.00, NULL, 'Approved', '5678901234', 'pol005', 'p1234570');


INSERT INTO bank (bankAccNumber, bankAccName, bankName, bankCode)
VALUES
('1234567890', 'John Doe', 'Bank of America', 'BA'),
('2345678901', 'Alice Smith', 'Wells Fargo', 'WF'),
('3456789012', 'Bob Johnson', 'Chase Bank', 'CHB'),
('4567890123', 'Charlie Brown', 'Citibank', 'CTB'),
('5678901234', 'Diana Garcia', 'US Bank', 'USB');

INSERT INTO insurance_card (cardNum, phID, pwID, expiredDate)
VALUES
('1234567890', 'c1234567', 'c7654321', '2025-04-23'),
('1234567891', 'c1234568', 'c7654322', '2025-04-23'),
('1234567892', 'c1234569', 'c7654323', '2025-04-23'),
('1234567893', 'c1234570', 'c7654324', '2025-04-23'),
('1234567894', 'c1234571', 'c7654325', '2025-04-23');

-- Insert data into the document table for the provided claims
INSERT INTO document (docID, docName, docContent, image, claimID)
VALUES
('d001', 'Claim Document 1', 'Document content for claim f1122334455', NULL, 'f1122334455'),
('d002', 'Claim Document 2', 'Document content for claim f2211334455', NULL, 'f2211334455'),
('d003', 'Claim Document 3', 'Document content for claim f3311224455', NULL, 'f3311224455'),
('d004', 'Claim Document 4', 'Document content for claim f4411324455', NULL, 'f4411324455'),
('d005', 'Claim Document 5', 'Document content for claim f5544332211', NULL, 'f5544332211');


-- NEW TABLES
--USER_INFO
create table user_info
(
user_name varchar(20) primary key,
password varchar(20) not null,
create_time timestamp not null default current_timestamp,
last_visit timestamp not null default current_timestamp check (last_visit >= create_time) -- last visit time must be later than create time
);

insert into user_info values ('admin1', '12345', current_timestamp, current_timestamp);
insert into user_info values ('admin2', '12345', current_timestamp, current_timestamp);
insert into user_info values ('pholder1', '12345', current_timestamp, current_timestamp);
insert into user_info values ('pholder2', '12345', current_timestamp, current_timestamp);
insert into user_info values ('pholder3', '12345', current_timestamp, current_timestamp);
insert into user_info values ('ponwer1', '12345', current_timestamp, current_timestamp);
insert into user_info values ('ponwer2', '12345', current_timestamp, current_timestamp);
insert into user_info values ('isurveyor1', '12345', current_timestamp, current_timestamp);
insert into user_info values ('isurveyor2', '12345', current_timestamp, current_timestamp);
insert into user_info values ('imanager1', '12345', current_timestamp, current_timestamp);
select * from user_info;


create table customer(
cust_id varchar(20) primary key check (cust_id ~ '^c[0-9]{7}$'), -- customer id must be in the format of cxxxxxxx
cust_name varchar(50) not null,
cust_type varchar(20) not null,
user_name varchar(20) not null,
policy_owner varchar(20) check (policy_owner is null or policy_owner ~ '^c[0-9]{7}$'), -- policy owner id must be in the format of cxxxxxxx
bankAccNumber varchar(25) not null,
foreign key (user_name) references user_info(user_name)
);

drop table if exists customer;
select * from customer;
insert into customer values ('c1234567', 'Alice', 'policy holder', 'pholder1', 'c7654321', '1234567890');
insert into customer values ('c1234568', 'Bob', 'policy holder', 'pholder2', 'c7654321', '2345678901');
insert into customer values ('c1234569', 'Charlie', 'policy holder', 'pholder3', 'c7654322', '3456789012');
insert into customer values ('c7654321', 'RMIT University', 'policy owner', 'powner1', null, '4567890123');
insert into customer values ('c7654322', 'Lotte Co.', 'policy owner', 'powner2', null, '4678901234');
select * from customer;

create table dependent(
dep_id varchar(20) primary key check (dep_id ~ '^c[0-9]{7}$'), -- dependent id must be in the format of cxxxxxxx
dep_name varchar(50) not null,
dep_type varchar(20) not null, -- relationship with the owner
dep_owner varchar(20) not null check (dep_owner ~ '^c[0-9]{7}$'), -- dependent owner id must be in the format of cxxxxxxx
bankAccNumber varchar(25) not null,
foreign key (dep_owner) references customer(cust_id)
);

insert into dependent values ('c9876543', 'Harry Potter', 'Child', 'c1234567', '6789012345');
insert into dependent values ('c9876544', 'Hermione Granger', 'Child', 'c1234567', '6890123456');
insert into dependent values ('c9876545', 'Voldemort', 'Parent', 'c1234568', '6789012345');
select * from dependent;

create table provider(
prov_id varchar(20) primary key check (prov_id ~ '^p[0-9]{7}$'), -- provider id must be in the format of pxxxxxxx
prov_name varchar(50) not null,
position varchar(20) not null,
manager varchar(20) check (manager is null or manager ~ '^p[0-9]{7}$'), -- manager id must be in the format of pxxxxxxx
user_name varchar(20) not null,
foreign key (user_name) references user_info(user_name)
);

drop table if exists provider;


select * from provider;

insert into provider values ('p1234567', 'Marie Curie', 'insurance surveyor', 'p9886543', 'isurveyor1');
insert into provider values ('p1234568', 'Elon Musk', 'insurance surveyor', 'p9886543', 'isurveyor2');
insert into provider values ('p7886543', 'Tesla', 'insurance manager', null, 'imanager1');

create table sys_admin(
sa_id varchar(20) primary key check (sa_id ~ '^s[0-9]{7}$'), -- system admin id must be in the format of sxxxxxxx
sa_name varchar(50) not null,
user_name varchar(20) not null,
foreign key (user_name) references user_info(user_name)
);

insert into sys_admin values ('s1122334', 'Steve Jobs', 'admin1');
insert into sys_admin values ('s2211335', 'Bill Gates', 'admin2');
select * from sys_admin;

create table insurance_card(
card_num varchar(20) primary key check (card_num ~ '^[0-9]{10}$'), -- insurance card number must be in the format of 10 digits
card_holder varchar(20) not null,
expiration_date date not null,
foreign key (card_holder) references customer(cust_id)
);

insert into insurance_card values ('1234567890', 'c1234567', '2023-12-31');
insert into insurance_card values ('2345678901', 'c1234568', '2023-12-31');
insert into insurance_card values ('3456789012', 'c1234569', '2023-12-31');
select * from insurance_card;

create table policy(
policy_id varchar(20) primary key,
policy_name varchar(20) not null,
policy_type varchar(20) not null,
policy_content varchar(250) not null,
cover_rate double precision not null,
policy_owner varchar(20) not null,
foreign key (policy_owner) references customer(cust_id)
);

insert into policy values ('p01', 'Health Insurance', 'Health', 'Cover all the medical expenses', 0.8, 'c7654321');
insert into policy values ('p02', 'Life Insurance', 'Life', 'Cover all the life expenses', 0.9, 'c7654322');

create table claim(
claim_id varchar(20) primary key check (claim_id ~ '^f[0-9]{10}$'), -- claim id must be in the format of fxxxxxxx
insured_person varchar(20) not null,
request_amount double precision not null check (request_amount > 0), -- amount must be positive
applied_policy varchar(20) not null,
claim_date date not null default current_date, -- claim date is the date when the claim is submitted
exam_date date not null default current_date check (exam_date >= claim_date), -- exam date is the date when the claim is examined
claim_status varchar(20) not null, -- claim status must be new, processing, done
claim_amount double precision check (claim_amount >= 0), -- amount must be non-negative
process_by varchar(20) not null, -- claim process by which provider
foreign key (applied_policy) references policy(policy_id),
foreign key (insured_person) references customer(cust_id),
foreign key (process_by) references provider(prov_id)
);

select * from claim;

insert into claim values ('f1234567890', 'c1234567', 1000, 'p01', '2023-12-31', '2023-12-31', 'new', 0, 'p1234567');
insert into claim values ('f2345678901', 'c1234568', 2000, 'p01', '2023-12-31', '2024-01-31', 'processing', 0, 'p1234568');
insert into claim values ('f3456789012', 'c1234569', 3000, 'p02', '2023-12-31', '2024-02-15', 'done', 0, 'p7886543');
insert into claim values ('f4567890123', 'c1234567', 4000, 'p02', '2023-12-31', '2024-03-31', 'processing', 0, 'p1234567');

create table bank(
bankAccNumber varchar(25) primary key not null,
bankAccName varchar(20) not null,
bankName varchar(20) not null,
balance double precision not null default 0
);

insert into bank values ('1234567890', 'Alice', 'ANZ', 0);
insert into bank values ('2345678901', 'Bob', 'NAB', 0);
insert into bank values ('3456789012', 'Charlie', 'CBA', 0);
insert into bank values ('4567890123', 'RMIT University', 'CBA', 0);
insert into bank values ('4678901234', 'Lotte Co.', 'ANZ', 0);
insert into bank values ('6789012345', 'Marie Curie', 'NAB', 0);
insert into bank values ('6890123456', 'Elon Musk', 'CBA', 0);
insert into bank values ('6901234567', 'Tesla', 'ANZ', 0);



CREATE TABLE document (
docID VARCHAR(10) PRIMARY KEY NOT NULL,
docName VARCHAR(50) NOT NULL, -- document name must be in the format of pdf
image BYTEA,
claimID VARCHAR(20) NOT NULL,
FOREIGN KEY (claimID) REFERENCES claim(claim_id)
);

insert into document values ('d01', 'document1', null, 'f1234567890');
insert into document values ('d02', 'document2', null, 'f2345678901');
insert into document values ('d03', 'document3', null, 'f3456789012');
insert into document values ('d04', 'document4', null, 'f4567890123');


create table log(
logID varchar(10) primary key not null,
user_name varchar(10) not null,
action_type varchar(10) not null,
alter_table varchar(20) not null,
alter_column varchar(20) not null,
entity_id varchar(10) not null,
old_value jsonb not null,
new_value jsonb not null,
action_time timestamp not null,
foreign key (user_name) references user_info(user_name)
);





