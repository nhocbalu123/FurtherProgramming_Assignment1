package org.claimsystem.oldfile.application.controller.dataIO;


import org.claimsystem.oldfile.customer.Customer;
import org.claimsystem.oldfile.customer.Dependent;
import org.claimsystem.oldfile.customer.NormalCustomer;
import org.claimsystem.oldfile.customer.PolicyHolder;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

// terminal
// random access
// txt file (Print Writer)
interface SystemDataIO<T> {
    public List<T> readFromFile(String location);

    public T scanData(String form);

    void writeToFile(String location, List<T> customers);

    void writeToFile(String location, T customer);
}

public class CustomerIO implements SystemDataIO<Customer>{

    @Override
    public List<Customer> readFromFile(String location) {
        List<Customer> customers = new ArrayList<>();
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(location))) {
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                Customer customer = scanData(line);
                customers.add(customer);
            }
        } catch (IOException e) {
            System.out.println(STR."Error: \{e.getMessage()}");
        }
        return customers;
    }

    @Override
    public Customer scanData(String form) {
        String[] data = form.split(";");
        String id = data[0];
        String name = data[1];
        String cardNumber = data[2];
        String customerType = data[3];
        switch (customerType) {
            case "PolicyHolder":
                PolicyHolder policyHolder = new PolicyHolder(new NormalCustomer(id, name));
                policyHolder.registerCard(cardNumber);
                String[] dependents = data[4].split(",");
                policyHolder.setDependents(Arrays.asList(dependents));
                return policyHolder;
            case "Dependent":
                Dependent dependent = new Dependent(new NormalCustomer(id, name));
                dependent.registerCard(cardNumber);
                dependent.setPolicyHolderID(data[4]);
                return dependent;
        }
        return null;
    }


    @Override
    public void writeToFile(String location, List<Customer> customers) {
        try {
            for (Customer customer: customers) {
                writeToFile(location, customer);
            }
        } catch (Exception e) {
            System.out.println(STR."Error: \{e}");
        }
    }

    @Override
    public void writeToFile(String location, Customer customer) {
        try {
            PrintWriter writer = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(location, true), StandardCharsets.ISO_8859_1)));
            writer.print(customer.getCustID());
            writer.print(";");
            writer.print(customer.getCustName());
            writer.print(";");
            writer.print(customer.getInsuranceCard());
            writer.print(";");
            if (customer instanceof PolicyHolder policyHolder) {
                writer.print("PolicyHolder;");
                writer.print(String.join(",", policyHolder.getDependents()));
            } else if (customer instanceof Dependent dependent) {
                writer.print("Dependent;");
                writer.print(dependent.getPolicyHolderID());
            }
            writer.println();
            writer.flush();
            writer.close();
        } catch (Exception e) {
            System.out.println(STR."Error : \{e}");
        }
    }
}
