package org.claimsystem.oldfile.customer;

public class CustomerFactory {
    public enum CustomerType {
        POLICY_HOLDER,
        DEPENDENT
    }
    public static Customer createCustomer(CustomerType customerType, String id, String name) {
        return switch (customerType) {
            case POLICY_HOLDER -> new PolicyHolder(new NormalCustomer(id, name));
            case DEPENDENT -> new Dependent(new NormalCustomer(id, name));
        };
    }
}
