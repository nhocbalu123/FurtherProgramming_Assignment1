package org.claimsystem.oldfile.customer;


import org.claimsystem.oldfile.application.FormatInput;

public abstract class Customer {
    private String custID;
    private String custName;
    private String iCardNumber;

    public Customer() {
        this.custID = "default";
        this.custName = "default";
        this.iCardNumber = "default";
    }

    public Customer(String id, String name) {
        setCustID(id);
        this.custName = name;
        this.iCardNumber = "default";
    }

    public Customer(String id, String name, String iCard) {
        this.custID = id;
        this.custName = name;
        this.iCardNumber = iCard;
    }
    // method
    public void registerCard(String cardNumber) {
        this.iCardNumber = cardNumber;
    }
    // getter and setter

    public void setCustID(String id) {
        boolean validFormat = FormatInput.verifyCustomerID(id);
        if (!validFormat) {
            return;
        }
        this.custID = id;
    }

    public void setCustName(String name) {
        this.custName = name;
    }

    public String getCustID() {
        return custID;
    }

    public String getCustName() {
        return custName;
    }

    public String getInsuranceCard() {
        return iCardNumber;
    }

    @Override
    public String toString() {
        return STR."Customer{custID='\{custID}\{'\''}, custName='\{custName}\{'\''}, iCardNumber='\{iCardNumber}\{'\''}\{'}'}";
    }
}
