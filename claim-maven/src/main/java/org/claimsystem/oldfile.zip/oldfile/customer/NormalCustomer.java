package org.claimsystem.oldfile.customer;

public class NormalCustomer extends Customer{
    public NormalCustomer(String id, String name) {
        super(id, name);
    }

    @Override
    public String toString() {
        return STR."NormalCustomer: \{super.toString()}";
    }
}
