
```mermaid
---
title: INSURANCE CLAIM MANAGEMENT SYSTEM
---
classDiagram
    Customer <|-- NormalCustomer
    Customer <|-- PolicyHolder
    Customer <|-- Dependent
    
    CustomerFactory ..> Customer
    FormatInput <.. ClaimController
    UserInput <.. ClaimView
    ClaimView --> IView
    ClaimProcessManager <-- ClaimController
    Application --> ClaimController
    ClaimCustomerManagement <-- ClaimController
    ClaimController --> DAO
    ClaimDAO --> Claim
    InsuranceDAO --> InsuranceCard
    CustomerDAO --> Customer
    
    
    
    
class Status {
<<ENUMERATION>>
NEW
PROCESSING
DONE
 }


class ClaimProcessManager {
    +add(): void
    +update(): void
    +delete(): void
    +search(): void
    +sort(): void
    +display(): void
    +saveData(): void
    +getClaimView(): ClaimView
 }
 
 class ClaimCustomerManagement {
     - customerToClaim: Map<Customer, List<Claim>>
     - ClaimCustomerManagement()
     + addClaim(): void
     + getAllClaims(): List<Claim>
     + getCustomer(Claim): Customer
     + getDataFromFile(String): Map<String, List<String>>
     + saveDataToFile(String, Map<String, List<String>>): void
 }

class ClaimController {
- claimDAO: ClaimDAO
- claimView: ClaimView
- insuranceDAO: InsuranceDAO
- customerDAO: CustomerDAO
- claimCustomerManagement: ClaimCustomerManagement
+ ClaimController(ClaimDAO, ClaimView, InsuranceDAO, CustomerDAO, ClaimCustomerManagement)
+ add()
+ update()
+ delete()
+ search()
+ sort()
+ display()
}


 ClaimDAO <-- DAO
ClaimDAO ..> ClaimIO
class ClaimDAO {
    - claimIO: ClaimIO
    + ClaimDAO()
    + add(Claim): void
    + update(Claim): void
    + delete(Claim): void
    + search(Claim): void
    + getAll(): Stream<Claim>
    + getDataFromFile(String): void
    + getOne(String): Optional<Claim>
    + saveAll(List<Claim>, String): void
    + saveOne(Claim, STring): void
 }
 CustomerDAO <-- DAO
 CustomerDAO ..> CustomerIO
 class CustomerDAO {
    - customerIO: CustomerIO
    + CustomerDAO()
    + add(Customer): void
    + update(Customer): void
    + delete(Customer): void
    + search(Customer): void
    + getAll(): Stream<Customer>
    + getDataFromFile(String): void
    + getOne(String): Optional<Customer>
    + saveAll(List<Customer>, String): void
    + saveOne(Customer, STring): void
 }

ICardDAO <-- DAO
ICardDAO ..> InsuranceCardIO
class ICardDAO {
    - insuranceCardIO: InsuranceCardIO
    + ICardDAO()
    + add(InsuranceCard): void
    + update(InsuranceCard): void
    + delete(InsuranceCard): void
    + search(InsuranceCard): void
    + getAll(): Stream<InsuranceCard>
    + getDataFromFile(String): void
    + getOne(String): Optional<InsuranceCard>
    + saveAll(List<InsuranceCard>, String): void
    + saveOne(InsuranceCard, STring): void
 }

class DAO {
    <<interface>>
+ add(T): void
+ update(T): void
+ delete(T): void
+ getAll(): Stream<T>
+ getOne(String): Optional<T>
 }

class SystemDataIO {
    <<interface>>
+ readFromFile(): List<Object>
+ scanData(): Object
+ writeToFile(String, List<Object>): void
+ writeToFile(String, Object): void
}

CustomerIO <-- SystemDataIO
class CustomerIO {
+ readFromFile(): List<Customer>
+ scanData(): Customer
+ writeToFile(String, List<Customer>): void
+ writeToFile(String, Customer): void
 }
InsuranceIO <-- SystemDataIO
class InsuranceIO {
+ readFromFile(): List<InsuranceCard>
+ scanData(): InsuranceCard
+ writeToFile(String, List<InsuranceCard>): void
+ writeToFile(String, InsuranceCard): void
 }
ClaimIO <-- SystemDataIO
class ClaimIO {
+ readFromFile(): List<Claim>
+ scanData(): Claim
+ writeToFile(String, List<Claim>): void
+ writeToFile(String, Claim): void
 }

class Application {
    - claimController ClaimController
    - exit boolean
    +Application()
    +run(): void
    +main(String[]): void
 }
 
 class ClaimView {
     + displayCommand():void
     + displayMenu():void
     + displaySearchMenu():void
     + displaySortMenu():void
     + displaySortOrder():void
     + displayUpdateMenu():void
     + getOption(String):String
     + printCards(List<InsuranceCard>):void
     + printCustomers(List<Customer>):void
     + printDetails(Claim):void
     + printDocumentList(List<String>):void
     + printError(Exception):void
     + printList(List<Claim>):void
     + printMessage(String):void
     + welcomeMessage():void
     - scanner:Scanner
 }
 class IView {
     <<inteface>>
     + displayMenu():void
     + displaySearchMenu():void
     + displayUpdateMenu():void
     + getOption(String):String
     + printDetails(T):void
     + printError(Exception):void
     + printMessage(String):void
 }
 class FormatInput {
     + formatDate(Date):String
     + formatDate(String):Date
     + verifyClaimID(String):boolean
     + verifyCustomerID(String):boolean
     + verifyExamAfterClaim(Date, Date):boolean
     + verifyInsuranceCard(String):boolean
     - PATTERN_CLAIM_ID:String
    - PATTERN_CUSTOMER_ID:String
    - PATTERN_DATE:String
    - PATTERN_INSURANCE_CARD:String
 }
 
 class UserInput {
     + Userlnput()
     + getScanner():Scanner
     + getUserInput():UserInput
     - sc:Scanner
     - userlnput:UserInput
 }

class Customer {
<<abstract>>
- name: String
- custName: String
- iCardNumber: String

+ registerICard(insurance.InsuranceCard) boolean
+ requestClaim(claim.Claim) boolean
}

class NormalCustomer {
    + NormalCustomer(String, String)
    + toString():String
}

class PolicyHolder {
    - PolicyHolder(Customer)
    + addbependent(String):void
    + getDependents():List<String>
    + removeDependent(String):void
    + setbependents(List<String>):void
    + toString():String
    - customer:Customer
    + dependents:List<String>
}

class Dependent {
    + Dependent(Customer)
    + getPolicyHolderID():String
    + setPolicyHolderID(String):void
    + toString():String
    - customer:Customer
    - policyHolderID:String
}

class CustomerFactory {
    + createCustomer(String, String):Customer
 }

class InsuranceCard{
- cardNumber: String
- cardHolder: customer.Customer
- policyOwner: String
- expirationDate: Date
+ registerCardHolder(customer.Customer) boolean
+ addOwner(customer.PolicyHolder) boolean
+ registerExpirationDate(Date) void

}
class Claim {
- claimID: String
- insuredPerson: String
- cardNum: String
- examDate: Date
- documents: List<String>
- claimAmount: double
- status: Enum
- receiverBankInfo: String

+ setClaimID(String) void
+ setInsuredPerson(String) void
+ setCardNum(String) void
+ setExamDate(Date) void
+ setDocuments(List<String>) void
+ setClaimAmount(double) void
+ setStatus(Enum) void
+ setReceiverBankInfo(String) void
+ getClaimID() String
+ getInsuredPerson() String
+ getCardNum() String
+ getExamDate() Date
+ getDocuments() List<String>
+ getClaimAmount() double
+ getStatus() Enum
+ getReceiverBank() String
+ addDocument(String) void
+ removeDocument(String) void
+ clearDocuments() void

}

class InsuranceCard {
    + InsuranceCard()
    + InsuranceCard(String, String, String)
    + addOwner(String):void
    + getCardHolder():String
    + getCardNumber():String
    + getExpiredDate():Date
    + getPolicyOwner():String
    + setCardHolder(String):void
    + setCardNumber(String):void
    + setExpiredDate(Date):void
    + toString():String
    - cardHolder:String
    - cardNumber:String
    - expiredDate:Date
    - policyOwner:String
}
```