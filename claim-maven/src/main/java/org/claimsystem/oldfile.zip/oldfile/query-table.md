select * from account;
select * from policy_holder;
select * from policy_owner;
select * from dependent;
select * from provider;
select * from sys_admin;
select * from session;
select * from policy;
select * from claim;
select * from bank;
select * from insurance_card;
select * from document;
select * from log;


UPDATE provider
SET managerid = NULL
WHERE pid IN ('p1234570', 'p1234571');
