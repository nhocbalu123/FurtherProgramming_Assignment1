package org.claimsystem.oldfile;



import org.claimsystem.oldfile.application.FormatInput;
import org.claimsystem.oldfile.claim.Claim;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static java.lang.StringTemplate.STR;

public class Test {
    public static void main(String[] args) {
        List<Claim> claimList = new ArrayList<>();
        // sort claim by claimID
        // sort claim by examDate
        // sort claim by claimDate
        // sort claim by claimAmount
        // sort claim by claimStatus
        Claim claim1 = new Claim("f1122334455", "1234567890", "c1234567");
        claim1.setClaimAmount(1000);
        claim1.setClaimDate(FormatInput.formatDate("01/01/2024"));
        claim1.setExamDate(FormatInput.formatDate("01/02/2024"));
        claim1.setStatus(Claim.ClaimStatus.NEW);
        Claim claim2 = new Claim("f2211334455", "1234567890", "c1234567");
        claim2.setClaimAmount(300);
        claim2.setClaimDate(FormatInput.formatDate("01/03/2023"));
        claim2.setExamDate(FormatInput.formatDate("01/05/2023"));
        claim2.setStatus(Claim.ClaimStatus.PROCESSING);
        Claim claim3 = new Claim("f3322114455", "1234567900", "c1234754");
        claim3.setClaimAmount(1500);
        claim3.setClaimDate(FormatInput.formatDate("01/01/2022"));
        claim3.setExamDate(FormatInput.formatDate("01/02/2022"));
        claim3.setStatus(Claim.ClaimStatus.DONE);
        Claim claim4 = new Claim("f4433221455", "1234567900", "c1234754");
        claim4.setClaimAmount(6000);
        claim4.setClaimDate(FormatInput.formatDate("01/01/2019"));
        claim4.setExamDate(FormatInput.formatDate("01/02/2021"));
        claim4.setStatus(Claim.ClaimStatus.DONE);
        Claim claim5 = new Claim("f5544332211", "1234587007", "c1236345");
        claim5.setClaimAmount(7200);
        claim5.setClaimDate(FormatInput.formatDate("01/01/2017"));
        claim5.setExamDate(FormatInput.formatDate("01/02/2020"));
        claim5.setStatus(Claim.ClaimStatus.DONE);
        claimList.add(claim1);
        claimList.add(claim2);
        claimList.add(claim3);
        claimList.add(claim4);
        claimList.add(claim5);
        for (Claim claim: claimList) {
            System.out.println(claim);
        }
        System.out.println("------------------------COMPARATOR-------------------");
        // sort by claimID
        // sort by examDate
        // sort by claimDate
        // sort by claimAmount
        System.out.println("Sort by claim amount");
        claimList.sort(new ClaimAmountComparator());
        printList(claimList);
        System.out.println("Sort by claim amount: desc");
        claimList.sort(Collections.reverseOrder(new ClaimAmountComparator()));
        printList(claimList);

        System.out.println("Sort by exam date");
        claimList.sort(new ExamDateComparator());
        printList(claimList);
        System.out.println("Sort by exam date: reverse order");
        claimList.sort(Collections.reverseOrder(new ExamDateComparator()));
        printList(claimList);

        System.out.println("Sort by claim date");
        claimList.sort(new ClaimDateComparator());
        printList(claimList);
        System.out.println("Sort by claim date: reverse order");
        claimList.sort(Collections.reverseOrder(new ClaimDateComparator()));
        printList(claimList);

        System.out.println("----------------STREAM----------------------------");
        List<Claim> sortbyClaimDate = claimList.stream().sorted(Comparator.comparing(Claim::getClaimDate)).toList();
        printList(sortbyClaimDate);
        System.out.println("claim date desc");
        List<Claim> sortbyClaimDatedesc = claimList.stream().sorted(Collections.reverseOrder(Comparator.comparing(Claim::getClaimDate))).toList();
        printList(sortbyClaimDatedesc);
        System.out.println("Sort by claim amount");
        List<Claim> sortByClaimAmount = claimList.stream().sorted(Comparator.comparing(Claim::getClaimAmount)).toList();
        printList(sortByClaimAmount);
        System.out.println("claim amount desc");
        List<Claim> sortByClaimAmountdesc = claimList.stream().sorted(Comparator.comparing(Claim::getClaimAmount).reversed()).toList();
        printList(sortByClaimAmountdesc);
        // create Claim Builder Class
        System.out.println("TEST CLAIM BUILDER");

        LocalDate lc1 = LocalDate.now();
        int date = 12, month = 4, year = 2024;
        LocalDate lc2 = LocalDate.of(year, month, date);
        String formatDate = lc2.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        System.out.println(lc1);
        System.out.println(lc2);
        System.out.println(formatDate);

        ClaimB newClaim = new ClaimB.ClaimBuilder("f9988776655", "c1234567").examDate(LocalDate.of(2024, 2, 3)).claimDate(LocalDate.of(2023, 1, 3)).claimStatus(ClaimB.ClaimBuilder.ClaimStatus.NEW).claimAmount(123.23).documents(List.of("doc1", "doc2")).receiverBank("vcb").build();
        System.out.println(newClaim);

        ClaimB claimB1 = new ClaimB.ClaimBuilder("f1122334455", "c1234567").cardNumber("1234567890")
                .claimAmount(1000)
                .claimDate(LocalDate.of(2024, 1, 1))
                .examDate(LocalDate.of(2024, 2, 1))
                .claimStatus(ClaimB.ClaimBuilder.ClaimStatus.NEW)
                .build();

        ClaimB claimB2 = new ClaimB.ClaimBuilder("f2211334455", "c1234567").cardNumber("2134567890")
                .claimAmount(300)
                .claimDate(LocalDate.of(2023, 3, 1))
                .examDate(LocalDate.of(2023, 5, 1))
                .claimStatus(ClaimB.ClaimBuilder.ClaimStatus.PROCESSING)
                .build();

        ClaimB claimB3 = new ClaimB.ClaimBuilder("f3322114455", "c1234754")
                .claimAmount(1500)
                .cardNumber("1234567900")
                .claimDate(LocalDate.of(2022, 1, 1))
                .examDate(LocalDate.of(2022, 2, 1))
                .claimStatus(ClaimB.ClaimBuilder.ClaimStatus.DONE)
                .build();

        ClaimB claimB4 = new ClaimB.ClaimBuilder("f4433221455", "c1234754")
                .claimAmount(6000)
                .cardNumber("1235467900")
                .claimDate(LocalDate.of(2019, 1, 1))
                .examDate(LocalDate.of(2021, 2, 1))
                .claimStatus(ClaimB.ClaimBuilder.ClaimStatus.DONE)
                .build();

        ClaimB claimB5 = new ClaimB.ClaimBuilder("f5544332211", "c1236345")
                .claimAmount(7200)
                .cardNumber("1234587007")
                .claimDate(LocalDate.of(2017, 1, 1))
                .examDate(LocalDate.of(2020, 2, 1))
                .claimStatus(ClaimB.ClaimBuilder.ClaimStatus.DONE)
                .build();
        List<ClaimB> claimList1 = new ArrayList<>();
        claimList1.add(claimB1);
        claimList1.add(claimB2);
        claimList1.add(claimB3);
        claimList1.add(claimB4);
        claimList1.add(claimB5);

        for (ClaimB claim: claimList1) {
            System.out.println(claim);
        }

        System.out.println("CLAIM TABLE");
        System.out.println("-".repeat(50));
        System.out.println(STR."|\{" ".repeat(19)}CLAIM DATA\{" ".repeat(19)}|");
        System.out.println("-".repeat(50));
        String format = "|%-10s|%-10s|%-10s|%-10s|%-10s|%-10s|%-10s|%-10s|%n";
        System.out.printf(format, "Claim ID", "Insured Person", "Card Number", "Exam Date", "Claim Date", "Claim Amount", "Status", "Receiver Bank");
        for (ClaimB claim: claimList1) {
            System.out.printf(format, claim.getClaimID(), claim.getInsuredPerson(), claim.getCardNumber(), InputValidation.formatDate(claim.getExamDate()), InputValidation.formatDate(claim.getClaimDate()), claim.getClaimAmount(), claim.getStatus(), claim.getReceiverBank());
        }
    }

    public static <T> void printList(List<T> list) {
        for (T object : list) {
            System.out.println(object);
        }
    }

}

class ExamDateComparator implements Comparator<Claim> {
    @Override
    public int compare(Claim c1, Claim c2) {
        return c1.getExamDate().compareTo(c2.getExamDate());
    }
}

class ClaimDateComparator implements Comparator<Claim> {
    @Override
    public int compare(Claim c1, Claim c2) {
        return c1.getClaimDate().compareTo(c2.getClaimDate());
    }
}

class ClaimAmountComparator implements Comparator<Claim> {
    @Override
    public int compare(Claim c1, Claim c2) {
        return Double.compare(c1.getClaimAmount(), c2.getClaimAmount());
    }
}