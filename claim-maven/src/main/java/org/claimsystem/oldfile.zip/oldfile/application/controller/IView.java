package org.claimsystem.oldfile.application.controller;

public interface IView<T> {
    public void printDetails(T t);
    public void printMessage(String message);
    public void printError(Exception e);
    public void displayMenu();
    public String getOption(String prompt);
    public void displayUpdateMenu();
    public void displaySearchMenu();
}
