package org.claimsystem.oldfile;

import java.time.LocalDate;
import java.util.List;

public class ClaimB {
    private final String claimID;
    private final String insuredPerson;
    private final String cardNumber;
    private final LocalDate examDate;
    private final LocalDate claimDate;
    private final List<String> documents;
    private final double claimAmount;
    private final String receiverBank;
    private final ClaimBuilder.ClaimStatus status;
    private ClaimB(ClaimBuilder builder) {
        this.claimID = builder.claimID;
        this.insuredPerson = builder.insuredPersonID;
        this.cardNumber = builder.cardNumber;
        this.examDate = builder.examDate;
        this.claimDate = builder.claimDate;
        this.documents = builder.documents;
        this.claimAmount = builder.claimAmount;
        this.receiverBank = builder.receiverBank;
        this.status = builder.status;
    }

    @Override
    public String toString() {
        return STR."ClaimB{claimID='\{claimID}\{'\''}, insuredPerson='\{insuredPerson}\{'\''}, cardNumber='\{cardNumber}\{'\''}, examDate=\{examDate}, claimDate=\{claimDate}, documents=\{documents}, claimAmount=\{claimAmount}, receiverBank='\{receiverBank}\{'\''}\{'}'}";
    }


    public static class ClaimBuilder {
        public enum ClaimStatus {
            NEW, PROCESSING, DONE
        }
        private final String claimID;
        private final String insuredPersonID;
        private String cardNumber;
        private LocalDate examDate;
        private LocalDate claimDate;
        private List<String> documents;
        private double claimAmount;
        private ClaimStatus status;
        private String receiverBank;

        public ClaimBuilder(String claimID, String insuredPersonID) {
            this.claimID = claimID;
            this.insuredPersonID = insuredPersonID;
        }

        public ClaimBuilder cardNumber(String cardNumber) {
            this.cardNumber = cardNumber;
            return this;
        }

        public ClaimBuilder examDate(LocalDate examDate) {
            this.examDate = examDate;
            return this;
        }

        public ClaimBuilder claimDate(LocalDate claimDate) {
            this.claimDate = claimDate;
            return this;
        }

        public ClaimBuilder documents(List<String> documents) {
            this.documents = documents;
            return this;
        }

        public ClaimBuilder claimAmount(double claimAmount) {
            this.claimAmount = claimAmount;
            return this;
        }

        public ClaimBuilder claimStatus(ClaimStatus status) {
            this.status = status;
            return this;
        }

        public ClaimBuilder receiverBank(String bank) {
            this.receiverBank = bank;
            return this;
        }

        public ClaimB build() {
            return new ClaimB(this);
        }

        private void validateClaimObject() {


        }
    }

    public String getClaimID() {
        return claimID;
    }

    public String getInsuredPerson() {
        return insuredPerson;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public LocalDate getExamDate() {
        return examDate;
    }

    public LocalDate getClaimDate() {
        return claimDate;
    }

    public List<String> getDocuments() {
        return documents;
    }

    public double getClaimAmount() {
        return claimAmount;
    }

    public String getReceiverBank() {
        return receiverBank;
    }

    public ClaimBuilder.ClaimStatus getStatus() {
        return status;
    }
}
