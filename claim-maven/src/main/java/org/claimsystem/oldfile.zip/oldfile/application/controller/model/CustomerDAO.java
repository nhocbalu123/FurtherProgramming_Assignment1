package org.claimsystem.oldfile.application.controller.model;

import org.claimsystem.oldfile.application.controller.dataIO.CustomerIO;
import org.claimsystem.oldfile.customer.Customer;


import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

public class CustomerDAO implements DAO<Customer>{
    private Map<String, Customer> customerMap;
    private final CustomerIO customerIO = new CustomerIO();

    public CustomerDAO() {
        customerMap = new HashMap<>();
    }

    @Override
    public Optional<Customer> getOne(String id) {
        return Optional.ofNullable(customerMap.get(id));
    }

    @Override
    public Stream<Customer> getAll() {
        return customerMap.values().stream();
    }

    @Override
    public void add(Customer customer) {
        customerMap.put(customer.getCustID(), customer);
    }

    @Override
    public void update(Customer customer) throws ParseException {
        getOne(customer.getCustID()).ifPresent(c -> {
            c.setCustID(customer.getCustID());
            c.setCustName(customer.getCustName());
            c.registerCard(customer.getInsuranceCard());
        });
    }

    @Override
    public void delete(Customer customer) {
        getOne(customer.getCustID()).ifPresent(c -> customerMap.remove(c.getCustID()));
    }

    public void getDataFromFile(String location) {
        List<Customer> customers = customerIO.readFromFile(location);
        System.out.println(customers.size());
        for (Customer customer : customers) {
            customerMap.put(customer.getCustID(), customer);
        }
    }

    public void saveAll(List<Customer> customers, String location) {
        customerIO.writeToFile(location, customers);
    }

    public void saveOne(Customer customer, String location) {
        customerIO.writeToFile(location, customer);
    }




}
