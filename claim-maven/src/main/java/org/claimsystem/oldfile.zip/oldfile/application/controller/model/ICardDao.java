package org.claimsystem.oldfile.application.controller.model;

import org.claimsystem.oldfile.application.controller.dataIO.InsuranceIO;
import org.claimsystem.oldfile.insurance.InsuranceCard;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

public class ICardDao {
    private Map<String, InsuranceCard> idToCard;
    private final InsuranceIO insuranceIO = new InsuranceIO();
    public ICardDao() {
        idToCard = new HashMap<>();
    }

    public Optional<InsuranceCard> getOne(String id) {
        return Optional.ofNullable(idToCard.get(id));
    }

    public Stream<InsuranceCard> getAll() {
        return this.idToCard.values().stream();
    }

    public void save(InsuranceCard insuranceCard) {
        this.idToCard.put(insuranceCard.getCardNumber(), insuranceCard);
    }

    public void update(InsuranceCard updateCard) {
        getOne(updateCard.getCardNumber()).ifPresent(card -> {
                    card.setCardHolder(updateCard.getCardHolder());
                    card.addOwner(updateCard.getPolicyOwner());
                    card.setExpiredDate(updateCard.getExpiredDate());
                }
        );
    }

    public void delete(InsuranceCard deleteCard) {
        getOne(deleteCard.getCardNumber()).ifPresent(existCard -> idToCard.remove(existCard.getCardNumber()));
    }

    public void getDataFromFile(String location) {
        List<InsuranceCard> cards = insuranceIO.readFromFile(location);
        for (InsuranceCard card : cards) {
            idToCard.put(card.getCardNumber(), card);
        }
    }

    public void saveAll(List<InsuranceCard> cards, String location) {
        insuranceIO.writeToFile(location, cards);
    }

    public void saveOne(InsuranceCard card, String location) {
        insuranceIO.writeToFile(location, card);
    }


}
