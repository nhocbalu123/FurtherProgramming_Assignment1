package org.claimsystem.oldfile.application.controller.model;


import org.claimsystem.oldfile.application.controller.dataIO.ClaimIO;
import org.claimsystem.oldfile.claim.Claim;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

public class ClaimDAO implements DAO<Claim> {
    private Map<String, Claim> claimMap;

    private final ClaimIO claimIO;

    public ClaimDAO() {
        claimMap = new HashMap<>();
        claimIO = new ClaimIO();
    }

    @Override
    public Optional<Claim> getOne(String id) {
        return Optional.ofNullable(claimMap.get(id));
    }

    @Override
    public Stream<Claim> getAll() {
        return claimMap.values().stream();
    }

    @Override
    public void add(Claim claim) {
        claimMap.put(claim.getClaimID(), claim);
    }

    @Override
    public void update(Claim claim) throws ParseException {
        getOne(claim.getClaimID()).ifPresent(claim1 -> {
            claim1.setInsuredPersonID(claim.getInsuredPersonID());
            claim1.setCardNumber(claim.getCardNumber());
            claim1.setExamDate(claim.getExamDate());
            claim1.setClaimDate(claim.getClaimDate());
            claim1.setDocuments(claim.getDocuments());
            claim1.setClaimAmount(claim.getClaimAmount());
            claim1.setStatus(claim.getStatus());
            claim1.setReceiverBank(claim.getReceiverBank());
        });
    }

    @Override
    public void delete(Claim claim) {
        getOne(claim.getClaimID()).ifPresent(claim1 -> claimMap.remove(claim1.getClaimID()));
    }

    public void getDataFromFile(String location) {
        List<Claim> claims = claimIO.readFromFile(location);
        for (Claim claim : claims) {
            claimMap.put(claim.getClaimID(), claim);
        }
    }

    public void saveAll(List<Claim> claims, String location) {
        claimIO.writeToFile(location, claims);
    }

    public void saveOne(Claim claim, String location) {
        claimIO.writeToFile(location, claim);
    }

}
