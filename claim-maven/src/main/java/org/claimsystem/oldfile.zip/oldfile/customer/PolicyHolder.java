package org.claimsystem.oldfile.customer;

import java.util.ArrayList;
import java.util.List;

public class PolicyHolder extends Customer {
    private Customer customer;
    private List<String> dependents;

    public PolicyHolder(Customer c) {
        super(c.getCustID(), c.getCustName());
        this.customer = c;
    }

    public void addDependent(String id) {
        dependents.add(id);
    }

    public void removeDependent(String id) {
        dependents.remove(id);
    }

    public List<String> getDependents() {
        return dependents;
    }

    public void setDependents(List<String> dependents) {
        this.dependents = dependents;
    }

    @Override
    public String toString() {
        return STR."Policy Holder: \{super.toString()}";
    }
}
