package org.claimsystem.oldfile;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class InputValidation {
    private static final String PATTERN_DATE = "dd/MM/yyyy";
    private static final String PATTERN_CLAIM_ID = "f\\d{10}";
    private static final String PATTERN_CUSTOMER_ID = "c\\d{7}";
    private static final String PATTERN_INSURANCE_CARD = "\\d{10}";

    public static boolean verifyCustomerID(String id) {
        if (!id.matches(PATTERN_CUSTOMER_ID)) {
            return false;
        }
        return true;
    }

    public static boolean verifyClaimID(String id) {
        if (!id.matches(PATTERN_CLAIM_ID)) {
            return false;
        }
        return true;
    }

    public static boolean verifyCardNum(String cardNum) {
        if (!cardNum.matches(PATTERN_INSURANCE_CARD)) {
            return false;
        }
        return true;
    }

    public static boolean checkClaimBeforeExam(LocalDate examDate, LocalDate claimDate) {
        if (examDate.isBefore(claimDate)) {
            System.out.println("Exam date must be after claim date!");
            return false;
        }
        return true;
    }

    public static String formatDate(LocalDate date) {
        return date.format(DateTimeFormatter.ofPattern(PATTERN_DATE));
    }

}
