package org.claimsystem.oldfile.application.controller.dataIO;



import org.claimsystem.oldfile.application.FormatInput;
import org.claimsystem.oldfile.insurance.InsuranceCard;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class InsuranceIO implements SystemDataIO<InsuranceCard>{
    @Override
    public List<InsuranceCard> readFromFile(String location) {
        List<InsuranceCard> cards = new ArrayList<>();
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(location))) {
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                InsuranceCard card = scanData(line);
                cards.add(card);
            }
        } catch (IOException e) {
            System.out.println(STR."Error: \{e.getMessage()}");
        }
        return cards;
    }


    @Override
    public InsuranceCard scanData(String form) {
        String[] data = form.split(";");
        InsuranceCard card = new InsuranceCard();
        for (int i = 0; i < data.length; i++) {
            switch (i) {
                case 0: card.setCardNumber(data[i]); break;
                case 1: card.setCardHolder(data[i]); break;
                case 2: card.addOwner(data[i]); break;
                case 3: card.setExpiredDate(FormatInput.formatDate(data[i])); break;
            }
        }
        return card;
    }


    @Override
    public void writeToFile(String location, List<InsuranceCard> cards) {
        try {
            for (InsuranceCard card : cards) {
                writeToFile(location, card);
            }
        } catch (Exception e) {
            System.out.println(STR."Error: \{e}");
        }
    }

    @Override
    public void writeToFile(String location, InsuranceCard card) {
        try {
            PrintWriter writer = new PrintWriter(new OutputStreamWriter(new FileOutputStream(location, true), StandardCharsets.ISO_8859_1));
            writer.print(card.getCardNumber());
            writer.print(";");
            writer.print(card.getCardHolder());
            writer.print(";");
            writer.print(card.getPolicyOwner());
            writer.print(";");
            writer.print(FormatInput.formatDate(card.getExpiredDate()));
            writer.println();
            writer.flush();
            writer.close();
        } catch (Exception e) {
            System.out.println(STR."Error: \{e}");
        }
    }
}
