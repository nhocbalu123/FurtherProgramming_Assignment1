package org.claimsystem.oldfile.customer;


public class Dependent extends Customer {
    private Customer customer;
    private String policyHolderID;

    public Dependent(Customer c) {
        super(c.getCustID(), c.getCustName());
        this.customer = c;
    }

    public void setPolicyHolderID(String id) {
        this.policyHolderID = id;
    }

    public String getPolicyHolderID() {
        return policyHolderID;
    }

    @Override
    public String toString() {
        return STR."Dependent: \{super.toString()}";
    }

}
