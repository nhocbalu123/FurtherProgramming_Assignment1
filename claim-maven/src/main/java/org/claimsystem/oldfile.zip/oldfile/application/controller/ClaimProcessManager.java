package application.controller;

public interface ClaimProcessManager {
    public void add();
    public void update();
    public void delete();
    public void search();
    public void sort();
    public void display();

}
