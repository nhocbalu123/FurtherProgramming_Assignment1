package org.claimsystem.oldfile.application;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FormatInput {
    private static final String PATTERN_DATE = "dd/MM/yyyy";
    private static final String PATTERN_CLAIM_ID = "f\\d{10}";
    private static final String PATTERN_CUSTOMER_ID = "c\\d{7}";
    private static final String PATTERN_INSURANCE_CARD = "\\d{10}";

    public static Date formatDate(String date) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat(PATTERN_DATE);
            return dateFormat.parse(date);
        } catch (ParseException pe) {
            System.out.println(STR."Error :\{pe}");
        }
        return null;
    }

    public static String formatDate(Date date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(PATTERN_DATE);
        return dateFormat.format(date);
    }

    public static boolean verifyExamAfterClaim(Date examDate, Date claimDate) {
        if (examDate.before(claimDate)) {
            System.out.println("Exam date must be after claim date!");
            return false;
        }
        return true;
    }

    public static boolean verifyClaimID(String id) {
        if (!id.matches(PATTERN_CLAIM_ID)) {
            System.out.println("Invalid claim id!");
            return false;
        }
        return true;
    }

    public static boolean verifyCustomerID(String id) {
        if (!id.matches(PATTERN_CUSTOMER_ID)) {
            System.out.println("Invalid customer id!");
            return false;
        }
        return true;
    }

    public static boolean verifyInsuranceCard(String card) {
        if (!card.matches(PATTERN_INSURANCE_CARD)) {
            System.out.println("Invalid insurance card!");
            return false;
        }
        return true;
    }
}
