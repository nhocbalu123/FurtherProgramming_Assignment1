package org.claimsystem.oldfile.application;

import java.util.Scanner;

public class UserInput {
    // this is singleton pattern
    private static UserInput userInput;
    private final Scanner sc;

    public UserInput() {
        this.sc = new Scanner(System.in);
    }

    public static UserInput getUserInput() {
        if (userInput == null) {
            userInput = new UserInput();
        }
        return userInput;
    }

    public Scanner getScanner() {
        return sc;
    }

}
