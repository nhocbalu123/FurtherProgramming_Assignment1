package org.claimsystem.oldfile;
import java.sql.*;
import java.time.LocalDate;
import java.util.Map;
import java.util.StringJoiner;

public class ClaimPostgreSQL {
    public Connection connectToDB(String dbName, String user, String password)
    {
        Connection conn = null;
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/" + dbName, user, password);
            if (conn == null) {
                System.out.println("Failed to make connection!");
            } else {
                System.out.println("Connection established!");
            }
        } catch (Exception e) {
            System.err.println(STR."\{e.getClass().getName()}: \{e.getMessage()}");
        }
        return conn;
    }

    public void createTable(Connection conn, String tableName) {
        Statement statement;
        try {
            String createTableQuery = STR."create table \{tableName}(claim_id varchar(100) primary key, insured_person varchar(100), insurance_card varchar (50), exam_date date, claim_date date, document varchar (100), claim_amount double precision, status varchar (50), receiver_bank varchar (50))";
            statement = conn.createStatement();
            statement.executeUpdate(createTableQuery);
            System.out.println("Create table successfully!");
        } catch (Exception e) {
            System.err.println(STR."\{e.getClass().getName()}: \{e.getMessage()}");
        }
    }

    public void insertRow(Connection conn, String tableName, ClaimB claimObject) {
        try {
            String insertRowQuery = STR."insert into \{tableName}(claim_id, insured_person, insurance_card, exam_date, claim_date, document, claim_amount, status, receiver_bank) values(?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(insertRowQuery);
            ps.setString(1, claimObject.getClaimID());
            ps.setString(2, claimObject.getInsuredPerson());
            ps.setString(3, claimObject.getCardNumber());
            ps.setDate(4, Date.valueOf(claimObject.getExamDate()));
            ps.setDate(5, Date.valueOf(claimObject.getClaimDate()));
            ps.setString(6, claimObject.getDocuments().toString());
            ps.setDouble(7, claimObject.getClaimAmount());
            ps.setString(8, claimObject.getStatus().toString());
            ps.setString(9, claimObject.getReceiverBank());
            ps.executeUpdate();
            System.out.println("Insert row successfully!");
        } catch (Exception e) {
            System.err.println(STR."\{e.getClass().getName()}: \{e.getMessage()}");
        }
    }

    public void readData(Connection conn, String tableName) {
        Statement statement;
        ResultSet resultSet;
        try {
            String readDataQuery = STR."select * from \{tableName}";
            statement = conn.createStatement();
            resultSet = statement.executeQuery(readDataQuery);
            while (resultSet.next()) {
                System.out.println(STR."Claim ID: \{resultSet.getString("claim_id")}");
                System.out.println(STR."Insured Person: \{resultSet.getString("insured_person")}");
                System.out.println(STR."Insurance Card: \{resultSet.getString("insurance_card")}");
                System.out.println(STR."Exam Date: \{resultSet.getDate("exam_date")}");
                System.out.println(STR."Claim Date: \{resultSet.getDate("claim_date")}");
                System.out.println(STR."Document: \{resultSet.getString("document")}");
                System.out.println(STR."Claim Amount: \{resultSet.getDouble("claim_amount")}");
                System.out.println(STR."Status: \{resultSet.getString("status")}");
                System.out.println(STR."Receiver Bank: \{resultSet.getString("receiver_bank")}");
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void updateData(Connection conn, String tableName, String claimID, String columnName,String newValue)
    {
        PreparedStatement statement;
        try {
            String updateQuery = STR."update \{tableName} set \{columnName} = ? where claim_id = ?";
            statement = conn.prepareStatement(updateQuery);
            if (columnName.equals("claim_date") || columnName.equals("exam_date")) {
                statement.setDate(1, Date.valueOf(LocalDate.parse(newValue)));
            } else if (columnName.equals("claim_amount")) {
                statement.setDouble(1, Double.parseDouble(newValue));
            } else {
                statement.setString(1, newValue);
            }
            statement.setString(2, claimID);
            statement.executeUpdate();
            System.out.println("Data update!");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void searchData(Connection conn, String tableName, Map<String, String> searchFields) {
        if (searchFields.isEmpty()) {
            System.out.println("No search criteria provided.");
            return;
        }

        StringJoiner whereClause = new StringJoiner(" AND ");
        for (Map.Entry<String, String> entry : searchFields.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();

            if (key.equals("claim_date") || key.equals("exam_date")) {
                // Format and quote dates appropriately for SQL
                whereClause.add(key + " = '" + Date.valueOf(value) + "'");
            } else if (key.equals("claim_amount")) {
                // Directly use the numeric value for amounts
                whereClause.add(key + " = " + Double.parseDouble(value));
            } else {
                // For strings, ensure they are escaped properly (this simplistic example may need real escaping in production code)
                whereClause.add(STR."\{key} = '\{value}'");
            }
        }

        String query = "SELECT * FROM " + tableName + " WHERE " + whereClause;
        try (Statement statement = conn.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            System.out.println("SEARCH RESULTS:");
            while (resultSet.next()) {
                System.out.println("Claim ID: " + resultSet.getString("claim_id"));
                System.out.println("Insured Person: " + resultSet.getString("insured_person"));
                System.out.println("Insurance Card: " + resultSet.getString("insurance_card"));
                System.out.println("Exam Date: " + resultSet.getDate("exam_date"));
                System.out.println("Claim Date: " + resultSet.getDate("claim_date"));
                System.out.println("Document: " + resultSet.getString("document"));
                System.out.println("Claim Amount: " + resultSet.getDouble("claim_amount"));
                System.out.println("Status: " + resultSet.getString("status"));
                System.out.println("Receiver Bank: " + resultSet.getString("receiver_bank"));
            }
        } catch (SQLException e) {
            System.err.println("SQL error: " + e.getMessage());
        }
    }

    public void deleteRow(Connection conn, String tableName, String claimID) {
        PreparedStatement statement;
        try {
            String deleteQuery = String.format("delete from %s where claim_id = %s", tableName, "?");
            statement = conn.prepareStatement(deleteQuery);
            statement.setString(1, claimID);
            statement.executeUpdate();
            System.out.println("Delete row successfully!");
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
