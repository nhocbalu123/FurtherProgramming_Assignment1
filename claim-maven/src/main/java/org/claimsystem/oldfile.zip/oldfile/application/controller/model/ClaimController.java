package org.claimsystem.oldfile.application.controller.model;


import application.controller.ClaimProcessManager;
import org.claimsystem.oldfile.application.controller.ClaimView;
import org.claimsystem.oldfile.application.FormatInput;
import org.claimsystem.oldfile.claim.Claim;

import java.util.*;

public class ClaimController implements ClaimProcessManager {
    private final ClaimDAO claimDAO;
    private final CustomerDAO customerDAO;
    private final ICardDao insuranceDAO;
    private ClaimCustomerManagement ccmanagement;
    private final ClaimView claimView;


    public enum UpdateOption {
        CLAIMDATE, CLAIMAMOUNT, EXAMDATE, STATUS, INSUREDPERSONID, CARDNUMBER, DOCUMENTS
    }

    public enum SearchOption {
        CLAIMID, CARDNUMBER, INSUREDPERSONID, STATUS, EXAMDATE, CLAIMDATE, CLAIMAMOUNT
    }

    public enum SortOption {
        CLAIMDATE, CLAIMAMOUNT, EXAMDATE
    }
    public enum SortOrder {
        ASC, DESC
    }


    public ClaimController(ClaimDAO claimDAO, ClaimCustomerManagement ccmanagement, ClaimView claimView, CustomerDAO customerDAO, ICardDao insuranceDAO) {
        this.claimDAO = claimDAO;
        this.ccmanagement = ccmanagement;
        this.claimView = claimView;
        this.customerDAO = customerDAO;
        this.insuranceDAO = insuranceDAO;
    }

    @Override
    public void add() {
        String claimID = claimView.getOption("Enter claim ID: ");
        if (claimDAO.getOne(claimID).isPresent()) {
            claimView.printMessage("Claim ID already exists");
            return;
        }
        String claimDate = claimView.getOption("Enter claim date: ");
        String insuredPersonID = claimView.getOption("Enter insured person ID: ");
        String cardNumber = claimView.getOption("Enter card number: ");
        String examDate = claimView.getOption("Enter exam date: ");
        if (!FormatInput.verifyExamAfterClaim(Objects.requireNonNull(FormatInput.formatDate(examDate)), FormatInput.formatDate(claimDate))) {
            return;
        }
        String documents = claimView.getOption("Enter documents: ");
        String claimAmount = claimView.getOption("Enter claim amount: ");
        String claimBank = claimView.getOption("Enter receiver bank: ");

        Claim newClaim = new Claim(claimID, cardNumber, insuredPersonID);
        newClaim.setClaimDate(FormatInput.formatDate(claimDate));
        newClaim.setExamDate(FormatInput.formatDate(examDate));
        List<String> documentList = new ArrayList<>(Arrays.asList(documents.split(",")));
        newClaim.setDocuments(documentList);
        newClaim.setClaimAmount(Double.parseDouble(claimAmount));
        newClaim.setReceiverBank(claimBank);
        claimView.printDetails(newClaim);

        claimDAO.add(newClaim); // add to claim map
        ccmanagement.addClaim(newClaim.getInsuredPersonID(), newClaim); // add to customer's claim list
        claimDAO.saveAll(claimDAO.getAll().toList(), "src/file/claim.txt");
    }
    @Override
    public void update() {
        claimView.displayUpdateMenu();
        String claimID = claimView.getOption("Enter claim ID to update: ");
        Claim claim = claimDAO.getOne(claimID).orElse(null);
        if (claim == null) {
            claimView.printMessage("Claim not found");
            return;
        }
        String input = claimView.getOption("Enter option to update: ");
        UpdateOption option = UpdateOption.values()[Integer.parseInt(input) - 1];
        switch (option) {
            case UpdateOption.CLAIMDATE -> {
                String claimDate = claimView.getOption("Enter new claim date: ");
                claim.setClaimDate(FormatInput.formatDate(claimDate));
            }
            case UpdateOption.CLAIMAMOUNT -> {
                String claimAmount = claimView.getOption("Enter new claim amount: ");
                claim.setClaimAmount(Double.parseDouble(claimAmount));
            }
            case UpdateOption.EXAMDATE -> {
                String examDate = claimView.getOption("Enter new exam date: ");
                claim.setExamDate(FormatInput.formatDate(examDate));
            }
            case UpdateOption.STATUS -> {
                String status = claimView.getOption("Enter new status: ");
                claim.setStatus(Claim.ClaimStatus.valueOf(status));
            }
            case UpdateOption.INSUREDPERSONID -> {
                String insuredPersonID = claimView.getOption("Enter new insured person ID: ");
                claim.setInsuredPersonID(insuredPersonID);
            }
            case UpdateOption.CARDNUMBER -> {
                String cardNumber = claimView.getOption("Enter new card number: ");
                claim.setCardNumber(cardNumber);
            }
            case UpdateOption.DOCUMENTS -> {
                String documents = claimView.getOption("Enter new documents: ");
                List<String> documentList = new ArrayList<>(Arrays.asList(documents.split(",")));
                claim.setDocuments(documentList);
            }
        }
    }
    @Override
    public void delete() {
        String claimID = claimView.getOption("Enter claim ID to delete: ");
        Claim claim = claimDAO.getOne(claimID).orElse(null);
        if (claim == null) {
            claimView.printMessage("Claim not found");
            return;
        }
        claimDAO.delete(claim);
        ccmanagement.removeClaim(claim.getInsuredPersonID(), claim);
        claimDAO.saveAll(claimDAO.getAll().toList(), "src/file/claim.txt");
    }
    @Override
    public void search() {
        claimView.displaySearchMenu();
        String input = claimView.getOption("Enter option to search: ");
        SearchOption option = SearchOption.values()[Integer.parseInt(input) - 1];
        switch (option) {
            case CLAIMID -> {
                String claimID = claimView.getOption("Enter claim ID to search: ");
                Claim claim = claimDAO.getOne(claimID).orElse(null);
                if (claim == null) {
                    claimView.printMessage("Claim not found");
                    return;
                }
                claimView.printDetails(claim);
            }
            case CARDNUMBER -> {
                String cardNumber = claimView.getOption("Enter card number to search: ");
                List<Claim> claims = claimDAO.getAll().filter(claim -> claim.getCardNumber().equals(cardNumber)).toList();
                if (claims.isEmpty()) {
                    claimView.printMessage("Claim not found");
                    return;
                }
                claimView.printList(claims);
            }
            case INSUREDPERSONID -> {
                String insuredPersonID = claimView.getOption("Enter insured person ID to search: ");
                List<Claim> claims = claimDAO.getAll().filter(claim -> claim.getInsuredPersonID().equals(insuredPersonID)).toList();
                if (claims.isEmpty()) {
                    claimView.printMessage("Claim not found");
                    return;
                }
                claimView.printList(claims);
            }
            case STATUS -> {
                String status = claimView.getOption("Enter status to search: ");
                List<Claim> claims = claimDAO.getAll().filter(claim -> claim.getStatus().toString().equals(status)).toList();
                if (claims.isEmpty()) {
                    claimView.printMessage("Claim not found");
                    return;
                }
                claimView.printList(claims);
            }
            case EXAMDATE -> {
                String startDate = claimView.getOption("Enter start date to search: ");
                String endDate = claimView.getOption("Enter end date to search: ");
                List<Claim> claims = claimDAO.getAll().filter(claim -> claim.getExamDate().after(FormatInput.formatDate(startDate)) && claim.getExamDate().before(FormatInput.formatDate(endDate))).toList();
                if (claims.isEmpty()) {
                    claimView.printMessage("Claim not found");
                    return;
                }
                claimView.printList(claims);
            }
            case CLAIMDATE -> {
                String startDate = claimView.getOption("Enter start date to search: ");
                String endDate = claimView.getOption("Enter end date to search: ");
                List<Claim> claims = claimDAO.getAll().filter(claim -> claim.getClaimDate().after(FormatInput.formatDate(startDate)) && claim.getClaimDate().before(FormatInput.formatDate(endDate))).toList();
                if (claims.isEmpty()) {
                    claimView.printMessage("Claim not found");
                    return;
                }
                claimView.printList(claims);
            }

            case CLAIMAMOUNT -> {
                String minAmount = claimView.getOption("Enter min amount to search: ");
                String maxAmount = claimView.getOption("Enter max amount to search: ");
                List<Claim> claims = claimDAO.getAll().filter(claim -> claim.getClaimAmount() >= Double.parseDouble(minAmount) && claim.getClaimAmount() <= Double.parseDouble(maxAmount)).toList();
                if (claims.isEmpty()) {
                    claimView.printMessage("Claim not found");
                    return;
                }
                claimView.printList(claims);
            }

            default -> claimView.printMessage("Invalid option");
        }


    }
    @Override
    public void sort() {
        claimView.displaySortMenu();
        String input = claimView.getOption("Enter option to sort (1/2): ");
        SortOption option = SortOption.values()[Integer.parseInt(input) - 1];
        String order = claimView.getOption("Enter order (1/2): ");
        SortOrder sortOrder = SortOrder.values()[Integer.parseInt(order)-1];
        Comparator<Claim> comparator = null;
        switch (option) {
            case CLAIMDATE -> comparator = Comparator.comparing(Claim::getClaimDate);
            case CLAIMAMOUNT -> comparator = Comparator.comparingDouble(Claim::getClaimAmount);
            case EXAMDATE -> comparator = Comparator.comparing(Claim::getExamDate);
            default -> claimView.printMessage("Invalid options!");
        }
        sortAndPrintClaim(comparator, sortOrder);
        

    }

    private void sortAndPrintClaim(Comparator<Claim> comparator, SortOrder sortOrder) {
        if (sortOrder == SortOrder.DESC) {
            comparator = comparator.reversed();
        }
        List<Claim> res = claimDAO.getAll().sorted(comparator).toList();
        claimView.printList(res);

    }

    public void saveData() {
        // save all data to file
        customerDAO.saveAll(customerDAO.getAll().toList(), "src/file/customer.txt");
        insuranceDAO.saveAll(insuranceDAO.getAll().toList(), "src/file/cards.txt");
        claimDAO.saveAll(claimDAO.getAll().toList(), "src/file/claim.txt");
    }


    @Override
    public void display() {
        this.claimDAO.getDataFromFile("src/file/claim.txt");
        this.customerDAO.getDataFromFile("src/file/customer.txt");
        this.insuranceDAO.getDataFromFile("src/file/cards.txt");
        claimView.printMessage("All claims: ");
        claimView.printList(this.claimDAO.getAll().toList());
        claimView.printMessage("All customers: ");
        claimView.printCustomers(this.customerDAO.getAll().toList());
        claimView.printMessage("All insurance cards: ");
        claimView.printCards(this.insuranceDAO.getAll().toList());
    }

    public ClaimView getClaimView() {
        return claimView;
    }
}
