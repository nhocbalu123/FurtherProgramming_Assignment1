package org.claimsystem.oldfile.insurance;

import org.claimsystem.oldfile.application.FormatInput;

import java.util.Date;


public class InsuranceCard {
    private String cardNumber;
    private String cardHolder;
    private String policyOwner;
    private Date expiredDate;

    public InsuranceCard() {
        this.cardNumber = "default";
        this.policyOwner = "default";
        this.cardHolder = "default";
        this.expiredDate = new Date();
    }


    public InsuranceCard(String cardNumber, String cardHolder, String policyOwner) {
        setCardNumber(cardNumber);
        this.cardHolder = cardHolder;
        this.policyOwner = policyOwner;
    }

    public void setCardHolder(String customer) {
        this.cardHolder = customer;
    }

    public String getCardHolder() {
        return cardHolder;
    }

    public void addOwner(String organisation) {
        this.policyOwner = organisation;
    }

    public String getPolicyOwner() {
        return policyOwner;
    }

    public void setCardNumber(String cardNumber) {
        boolean isValid = FormatInput.verifyInsuranceCard(cardNumber);
        if (!isValid) {
            return;
        }
        this.cardNumber = cardNumber;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public Date getExpiredDate() {
        return expiredDate;
    }

    public void setExpiredDate(Date date) {
        this.expiredDate = date;
    }

    @Override
    public String toString() {
        return "InsuranceCard{" +
                "cardNumber='" + cardNumber + '\'' +
                ", cardHolder='" + cardHolder + '\'' +
                ", policyOwner='" + policyOwner + '\'' +
                ", expiredDate=" + FormatInput.formatDate(expiredDate) +
                '}';
    }
}


