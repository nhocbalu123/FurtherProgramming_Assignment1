package org.claimsystem.oldfile.application.controller;
import org.claimsystem.oldfile.application.UserInput;
import org.claimsystem.oldfile.claim.Claim;
import org.claimsystem.oldfile.customer.Customer;
import org.claimsystem.oldfile.insurance.InsuranceCard;

import java.util.List;
import java.util.Scanner;

public class ClaimView implements IView<Claim> {
    private final Scanner scanner = UserInput.getUserInput().getScanner();

    public void welcomeMessage() {
        System.out.println("INSURANCE CLAIM MANAGEMENT SYSTEM");
    }

    public void displayCommand() {
        String prompt = """
                Please select an option to process:
                1. Add claim      2. Update claim
                3. Delete claim   4. Search claim
                5. Sort claim     6. Display data
                7. Save data      8. Exit
                """;
        System.out.println(prompt);
    }

    @Override
    public void printDetails(Claim claim) { System.out.println("Claim: ");
        System.out.println(claim);
    }



    public void printList(List<Claim> claims) {
        for (Claim c: claims) {
            printDetails(c);
        }
    }

    public void printCustomers(List<Customer> customers) {
        for (Customer c: customers) {
            System.out.println(c);
        }
    }

    public void printCards(List<InsuranceCard> cards) {
        for (InsuranceCard c: cards) {
            System.out.println(c);
        }
    }



    public void printDocumentList(List<String> documents) {
        for (String d: documents) {
            System.out.println(d);
        }
    }

    @Override
    public void printMessage(String message) {
        System.out.println(message);

    }

    @Override
    public void printError(Exception e) {
        System.err.println(STR."Error: \{e.getMessage()}");
    }


    @Override
    public void displayMenu() {
        System.out.println("Claim menu: ");
        System.out.println("1. Create claim");
        System.out.println("2. Update claim");
        System.out.println("3. Delete claim");
        System.out.println("4. Search claim");
        System.out.println("5. Sort claim");
        System.out.println("0. Exit");
    }

    @Override
    public String getOption(String prompt) {
        System.out.println(prompt);
        return scanner.nextLine();
    }

    @Override
    public void displayUpdateMenu() {
        System.out.println("1. Update claim date");
        System.out.println("2. Update claim amount");
        System.out.println("3. Update exam date");
        System.out.println("4. Update claim status");
        System.out.println("5. Update insured person");
        System.out.println("6. Update insurance card");
        System.out.println("7. Update documents");
    }

    @Override
    public void displaySearchMenu() {
        System.out.println("1. Search by claim ID");
        System.out.println("2. Search by insurance card");
        System.out.println("3. Search by insured person");
        System.out.println("4. Search by status");
        System.out.println("5. Search by exam date range");
        System.out.println("6. Search by claim date range");
        System.out.println("7. Search by claim amount range");
    }


    public void displaySortMenu() {
        System.out.println("1. Sort by claimDate");
        System.out.println("2. Sort by claimAmount");
        System.out.println("3. Sort by examDate");
    }

    public void displaySortOrder() {
        System.out.println("1. Ascending");
        System.out.println("2. Descending");
    }


}
