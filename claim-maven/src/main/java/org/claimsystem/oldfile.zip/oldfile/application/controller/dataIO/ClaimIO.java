package org.claimsystem.oldfile.application.controller.dataIO;

import org.claimsystem.oldfile.application.FormatInput;
import org.claimsystem.oldfile.claim.Claim;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class ClaimIO implements SystemDataIO<Claim> {
    @Override
    public List<Claim> readFromFile(String location) {
        List<Claim> claims = new ArrayList<>();
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(location))) {
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                Claim claim = scanData(line);
                claims.add(claim);
            }
        } catch (IOException e) {
            System.out.println(STR."Error: \{e}");
        }
        return claims;
    }

    @Override
    public Claim scanData(String form) {
        String[] data = form.split(";");
        String claimID = data[0];
        String claimDate = data[1];
        String insuredPersonID = data[2];
        String cardNumber = data[3];
        String examDate = data[4];
        String[] documents = data[5].split(",");
        double claimAmount = Double.parseDouble(data[6]);
        String status = data[7];
        String receiverBank = data[8];
        Claim claim = new Claim(claimID, cardNumber, insuredPersonID);
        claim.setClaimDate(FormatInput.formatDate(claimDate));
        claim.setExamDate(FormatInput.formatDate(examDate));
        claim.setDocuments(List.of(documents));
        claim.setClaimAmount(claimAmount);
        claim.setStatus(Claim.ClaimStatus.valueOf(status));
        claim.setReceiverBank(receiverBank);
        return claim;
    }

    @Override
    public void writeToFile(String location, List<Claim> claims) {
        try {
            for (Claim claim: claims) {
                writeToFile(location, claim);
            }
        } catch (Exception e) {
            System.out.println(STR."Error: \{e}");
        }
    }

    @Override
    public void writeToFile(String location, Claim claim) {
        try {
            PrintWriter writer = new PrintWriter(new OutputStreamWriter(new FileOutputStream(location, true), StandardCharsets.UTF_8));
            writer.print(claim.getClaimID());
            writer.print(";");
            writer.print(FormatInput.formatDate(claim.getClaimDate()));
            writer.print(";");
            writer.print(claim.getInsuredPersonID());
            writer.print(";");
            writer.print(claim.getCardNumber());
            writer.print(";");
            writer.print(FormatInput.formatDate(claim.getExamDate()));
            writer.print(";");
            writer.print(String.join(",", claim.getDocuments()));
            writer.print(";");
            writer.print(claim.getClaimAmount());
            writer.print(";");
            writer.print(claim.getStatus());
            writer.print(";");
            writer.print(claim.getReceiverBank());
            writer.println();
            writer.close();

        } catch (Exception e) {
            System.out.println(STR."Error: \{e}");
        }
    }

}

