package org.claimsystem.oldfile.application.controller.model;

import org.claimsystem.oldfile.claim.Claim;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ClaimCustomerManagement {
    public Map<String, List<Claim>> customerToClaims;
    public ClaimCustomerManagement() {
        this.customerToClaims = new HashMap<>();
    }

    public void addClaim(String customerId, Claim claim) {
        if (!customerToClaims.containsKey(customerId)) {
            customerToClaims.put(customerId, new ArrayList<>());
        }
        customerToClaims.get(customerId).add(claim);
    }

    public void removeClaim(String customerId, Claim claim) {
        if (customerToClaims.containsKey(customerId)) {
            customerToClaims.get(customerId).remove(claim);
        }
    }

    public List<Claim> getAllClaims(String customerId) {
        return customerToClaims.getOrDefault(customerId, new ArrayList<>());
    }

    public String getCustomer(Claim claim) {
        for (Map.Entry<String, List<Claim>> entry : customerToClaims.entrySet()) {
            if (entry.getValue().contains(claim)) {
                return entry.getKey();
            }
        }
        return null;
    }

    public Map<String, List<Claim>> getDataFromFile(String location) {
        return null;
    }

    public void saveDataToFile(Map<String, List<Claim>> data, String location) {

    }
}
