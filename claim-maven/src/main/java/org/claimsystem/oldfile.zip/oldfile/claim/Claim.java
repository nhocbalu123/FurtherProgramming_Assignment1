package org.claimsystem.oldfile.claim;

import org.claimsystem.oldfile.application.FormatInput;

import java.text.Format;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Claim {
    public enum ClaimStatus {
        NEW, PROCESSING, DONE
    }

    private String claimID;
    private String insuredPersonID;
    private String cardNumber;
    private Date examDate;
    private Date claimDate;
    private List<String> documents;
    private double claimAmount;
    private ClaimStatus status;
    private String receiverBank;

    public Claim() {
        this.claimID = "default";
        this.insuredPersonID = "default";
        this.cardNumber = "default";
        this.examDate = new Date();
        this.claimDate = new Date();
        this.documents = new ArrayList<>();
        this.claimAmount = 0.0;
        this.status = ClaimStatus.NEW;
        this.receiverBank = "default";
    }

    public Claim(String id, String cardNumber, String insuredPersonID) {
        setClaimID(id);
        this.cardNumber = cardNumber;
        this.insuredPersonID = insuredPersonID;
        this.examDate = new Date();
        this.claimDate = new Date();
        this.documents = new ArrayList<>();
        this.claimAmount = 0.0;
        this.status = ClaimStatus.NEW;
        this.receiverBank = "default";
    }

    public void setClaimID(String id) {
        if (!FormatInput.verifyClaimID(id)) {
           return;
        }
        this.claimID = id;
    }

    public void setInsuredPersonID(String id) {
        if(!FormatInput.verifyCustomerID(id)) {
            return;
        }
        this.insuredPersonID = id;
    }

    public void setCardNumber(String cardNumber) {
        if (!FormatInput.verifyInsuranceCard(cardNumber)) {
            return;
        }
        this.cardNumber = cardNumber;
    }

    public void setExamDate(Date date) {
        this.examDate = date;
    }

    public void setClaimDate(Date date) {
        this.claimDate = date;
    }

    public void setDocuments(List<String> documents) {
        this.documents = documents;
    }

    public void setClaimAmount(double amount) {
        this.claimAmount = amount;
    }

    public void setStatus(ClaimStatus status) {
        this.status = status;
    }

    public void setReceiverBank(String bank) {
        this.receiverBank = bank;
    }

    public String getClaimID() {
        return claimID;
    }

    public String getInsuredPersonID() {
        return insuredPersonID;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public Date getExamDate() {
        return examDate;
    }

    public Date getClaimDate() {
        return claimDate;
    }

    public List<String> getDocuments() {
        return documents;
    }

    public double getClaimAmount() {
        return claimAmount;
    }

    public ClaimStatus getStatus() {
        return status;
    }

    public String getReceiverBank() {
        return receiverBank;
    }

    public void addDocument(String document) {
        documents.add(document);
    }

    public void removeDocument(String document) {
        documents.remove(document);
    }

    public void clearDocuments() {
        documents.clear();
    }

    @Override
    public String toString() {
        return STR."Claim{claimID='\{claimID}\{'\''}, insuredPersonID='\{insuredPersonID}\{'\''}, cardNumber='\{cardNumber}\{'\''}, examDate=\{FormatInput.formatDate(examDate)}, claimDate=\{FormatInput.formatDate(claimDate)}, documents=\{documents}, claimAmount=\{claimAmount}, status=\{status}, receiverBank='\{receiverBank}\{'\''}\{'}'}";
    }
}
