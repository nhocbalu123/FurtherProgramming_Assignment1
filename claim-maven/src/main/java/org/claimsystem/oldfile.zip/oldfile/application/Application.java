package org.claimsystem.oldfile.application;
import org.claimsystem.oldfile.application.controller.ClaimView;
import org.claimsystem.oldfile.application.controller.model.*;


public class Application {
    private static boolean exit = false;
    private final ClaimController claimController;

    public enum Command {
        ADD, UPDATE, DELETE, SEARCH, SORT, DISPLAY, SAVEDATA, EXIT
    }

    public Application() {
        this.claimController = new ClaimController(new ClaimDAO(), new ClaimCustomerManagement(), new ClaimView(), new CustomerDAO(), new ICardDao());
    }

    public void run() {
        claimController.getClaimView().welcomeMessage();
        while (!exit) {
            claimController.getClaimView().displayCommand();
            try {
                String choice = claimController.getClaimView().getOption("Enter your choice: ");
                int choiceInt = Integer.parseInt(choice);
                if (choiceInt < 1 || choiceInt > Command.values().length) {
                    claimController.getClaimView().printMessage("Invalid choice, please try again");
                    continue;
                }
                Command command = Command.values()[Integer.parseInt(choice) - 1];
                switch (command) {
                    case ADD -> claimController.add();
                    case UPDATE -> claimController.update();
                    case DELETE -> claimController.delete();
                    case SEARCH -> claimController.search();
                    case SORT -> claimController.sort();
                    case DISPLAY -> claimController.display();
                    case SAVEDATA -> claimController.saveData();
                    default -> {
                       exit = true;
                    }
                }
            } catch (Exception e) {
                claimController.getClaimView().printMessage(e.getMessage());
            }

        }
    }

    public static void main(String[] args) {
        Application application = new Application();
        application.run();


    }
}
